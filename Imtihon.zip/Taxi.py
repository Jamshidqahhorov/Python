class Taxi:
    def __init__(self, id):
        self.id = id

    def __str__(self):
        return f"Taxi ID: {self.id}"
