class Trip:
    def __init__(self, startPlace, endPlace):
        self.startPlace = startPlace
        self.endPlace = endPlace

    def __str__(self):
        return f"{self.startPlace}, {self.endPlace}"
