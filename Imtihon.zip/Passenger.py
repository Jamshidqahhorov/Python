from Place import Place


class Passenger:
    def __init__(self, place):
        self.place = place

    def getPlace(self):
        return self.place
