from Taxi import Taxi


class TaxiCompany:
    def __init__(self):
        self.taxis = []

    def addTaxi(self, id):
        for taxi in self.taxis:
            if taxi.id == id:
                raise Exception("InvalidTaxiName")
        self.taxis.append(Taxi(id))

    def getAvailable(self):
        return [taxi for taxi in self.taxis]
