from Taxi import Taxi
from TaxiCompany import TaxiCompany
from Place import Place
from Passenger import Passenger
from TaxiManager import TaxiManager
from Trip import Trip

# Taksi kompaniyasini yaratish
taxiCompany = TaxiCompany()

# Kompaniyaga taksilarni qo'shish
taxiCompany.addTaxi("Taksi1")
taxiCompany.addTaxi("Taksi2")

# Joylarni yaratish
joy1 = Place("Manzil1", "Tuman1", "Mahalla1")
joy2 = Place("Manzil2", "Tuman2", "Mahalla2")

# Yo'lovchilarni yaratish
yolovchi1 = Passenger(joy1)
yolovchi2 = Passenger(joy2)

# Taksi boshqaruvchisini yaratish
taxiManager = TaxiManager()

# Yo'lovchilar uchun taksilarni chaqirish
taksi1 = taxiManager.callTaxi(yolovchi1)
taksi2 = taxiManager.callTaxi(yolovchi2)

# Yo'qotilgan sayohatlarni chiqarish
print(f"Yo'qotilgan sayohatlar: {taxiManager.getLostTrips()}")

# Taksilar uchun sayohatlarni boshlash va tugatish
if taksi1 is not None:
    taksi1.beginTrip(joy2)
    taksi1.terminateTrip()

if taksi2 is not None:
    taksi2.beginTrip(joy1)
    taksi2.terminateTrip()
