from Passenger import Passenger
from TaxiCompany import TaxiCompany


class TaxiManager:
    def __init__(self):
        self.taxiCompany = TaxiCompany()
        self.lostTrips = 0

    def callTaxi(self, passenger):
        availableTaxis = self.taxiCompany.getAvailable()
        if len(availableTaxis) == 0:
            self.lostTrips += 1
            return None
        else:
            return availableTaxis[0]

    def getLostTrips(self):
        return self.lostTrips
